import java.util.Scanner;

public class Main {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        double length=Double.parseDouble(sc.nextLine());
        if(length<=0){
            System.out.printf("%s","Length cannot be zero or negative.");
            return;
        }
        double width=Double.parseDouble(sc.nextLine());
        if(width<=0){
            System.out.printf("%s","Width cannot be zero or negative.");
            return;
        }
        double height=Double.parseDouble(sc.nextLine());


         if(height<=0){
            System.out.printf("%s","Height cannot be zero or negative.");
            return;
        }
        if(length>0&&width>0&&height>0) {
            Box box=new Box(length,width,height);
            System.out.printf("Surface Area - %.2f%n",box.calculateSurfaceArea());
            System.out.printf("Lateral Surface Area - %.2f%n",box.calculateLateralSurfaceArea());
            System.out.printf("Volume – %.2f%n",box.calculateVolume());
        }
    }

}
